const GROUNDSPEED_DECAY_MULT = 0.94;
const DRIVE_POWER = 0.5;
const REVERSE_POWER = 0.2;
const TURN_RATE = 0.06;
const MIN_SPEED_TO_TURN = 0.5;

function soldierClass() {
	this.key_num = 0;
	this.x = 75;
	this.y = 75;
	this.ang = 0;
	this.xspeed = 0;
	this.yspeed = 0;
	this.hp = 100;
	this.atk = 15;
	this.dfs = 10;
	this.soldierimage;
	this.name = "great bill";
	this.key_up = false;
	this.key_down = false;
	this.key_left = false;
	this.key_right = false;

	this.controlkeyup;
	this.controlkeydown;
	this.controlkeyleft;
	this.controlkeyright;
	this.setupinput = function (upkey, downkey, leftkey, rightkey) {
		this.controlkeyup = upkey;
		this.controlkeydown = downkey;
		this.controlkeyleft = leftkey;
		this.controlkeyright = rightkey;


    }
	this.reset = function (image ,soldiername) {
		this.soldierimage = image;
		this.name = soldiername;
		this.speed = 0;
		for (var eachRow = 0; eachRow < ROOM_ROWS; eachRow++) {
			for (var eachCol = 0; eachCol < ROOM_COLS; eachCol++) {
				var arrayIndex = rowColToArrayIndex(eachCol, eachRow);
				if (roomGrid[arrayIndex] == ROOM_PLAYERSTART) {
					roomGrid[arrayIndex] = ROOM_ROAD;
					this.ang = -Math.PI / 2;
					this.x = eachCol * ROOM_W + ROOM_W / 2;
					this.y = eachRow * ROOM_H + ROOM_H / 2;
					return;
				} // end of player start if
			} // end of col for
		} // end of row for
	} // end of soldierReset func

	this.move = function () {
		this.xspeed = 0;
		this.yspeed = 0;
		if (this.key_up) {
			this.yspeed=-5
			this.y += this.yspeed;
		}
		if (this.key_down) {
			this.yspeed = 5
			this.y += this.yspeed
		} 
			if (this.key_left) {
				this.xspeed = -5
				this.x += this.xspeed;
			}
			if (this.key_right) {
				this.xspeed = 5
				this.x += this.xspeed
			}
		

		
		soldierRoomHandling(this);
	}

	this.draw = function () {
		drawBitmapCenteredWithRotation(this.soldierimage, this.x, this.y, this.ang);
	}
}