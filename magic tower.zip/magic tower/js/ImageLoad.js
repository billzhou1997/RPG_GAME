var soldier1Pic = document.createElement("img");
//var soldier2Pic = document.createElement("img");
var roomPics = [];
var picsToLoad = 0;

function loadcount() {
    picsToLoad--;
   // console.log(picsToLoad);
    if (picsToLoad == 0) { MainProgram(); }


}
function imageloadandcheck(image, file) {
   
    image.onload = loadcount();

    image.src = "img/"+file;
}



function loadImageForRoomCode(roomCode, fileName) {
    roomPics[roomCode] = document.createElement("img");
    imageloadandcheck(roomPics[roomCode], fileName);
}



function LoadImages()
{
    var imageList = [
        { varName: soldier1Pic, theFile: "player1soldier.png" },
       // { varName: soldier2Pic, theFile: "player2soldier.png" },
        { roomType: ROOM_ROAD, theFile: "room_road.png" },
        { roomType: ROOM_WALL, theFile: "room_wall.png" },
        { roomType: ROOM_GOAL, theFile: "room_goal.png" },
        { roomType: ROOM_TREE, theFile: "room_tree.png" },
        { roomType: ROOM_FLAG, theFile: "room_flag.png" },
        { roomType: ROOM_DOOR, theFile: "room_door.png" },
        { roomType: ROOM_KEY, theFile: "room_key.png" },
        { roomType: ROOM_MONSTER1, theFile: "room_monster1.png" }
    ];

    picsToLoad = imageList.length;
    for (var i = 0; i < imageList.length; i++) {
        if (imageList[i].varName != undefined) {
            imageloadandcheck(imageList[i].varName, imageList[i].theFile);
        } else {
            loadImageForRoomCode(imageList[i].roomType, imageList[i].theFile);
        }
    }
}
