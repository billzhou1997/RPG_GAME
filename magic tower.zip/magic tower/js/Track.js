
const ROOM_W = 40;
const ROOM_H = 40;
const ROOM_GAP = 2;
const ROOM_COLS = 20;
const ROOM_ROWS = 15;
var lvl_num = 0;
var lvl1 = [     1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				 1, 3, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,
				 1, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1,
				 1, 0, 0, 1, 0, 0, 1, 6, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1,
				 1, 0, 8, 1, 0, 0, 1, 0, 0, 1, 0, 6, 7, 7, 1, 6, 0, 1, 0, 1,
				 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 6, 6, 1, 0, 1,
				 1, 0, 0, 1, 0, 0, 0, 7, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1,
				 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 0, 0, 1, 0, 0, 1,
				 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1,
				 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
				 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
				 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	             1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];



var lvl2 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 4, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 2, 0, 0, 3, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 5, 0, 0, 1,
	1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 5, 0, 1, 0, 0, 0, 0, 1,
	1, 0, 5, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1,
	1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 4, 1, 0, 0, 1, 0, 1,
	1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 4, 1, 0, 0, 1, 0, 1,
	1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1,
	1, 0, 5, 1, 0, 0, 0, 0, 0, 1, 0, 5, 0, 0, 0, 0, 0, 1, 0, 1,
	1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1,
	1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];




var lvl3 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 5, 0, 0, 1,
	1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 5, 0, 1, 0, 0, 0, 0, 1,
	1, 0, 5, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1,
	1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 4, 1, 0, 0, 1, 0, 1,
	1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 4, 1, 0, 0, 1, 0, 1,
	1, 0, 4, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1,
	1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1,
	1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1,
	1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];



var lvllist = [ lvl1, lvl2, lvl3 ];
var roomGrid = [];
const ROOM_ROAD = 0;
const ROOM_WALL = 1;
const ROOM_PLAYERSTART = 2;
const ROOM_GOAL = 3;
const ROOM_TREE = 4;
const ROOM_FLAG = 5;
const ROOM_DOOR = 6;
const ROOM_KEY = 7;
const ROOM_MONSTER1 = 8;
const ROOM_MONSTER2 = 9;

function TileTypeAtColRow(col, row) {
	if (col >= 0 && col < ROOM_COLS &&
		row >= 0 && row < ROOM_ROWS) {
		var roomIndexUnderCoord = rowColToArrayIndex(col, row);
		return roomGrid[roomIndexUnderCoord];
	} else {
		return ROOM_WALL;
	}
}
function soldierRoomHandling( soldier) {
	var soldierRoomCol = Math.floor(soldier.x / ROOM_W);
	var soldierRoomRow = Math.floor(soldier.y / ROOM_H);
	var roomIndexUnderSoldier = rowColToArrayIndex(soldierRoomCol, soldierRoomRow);

	if (soldierRoomCol >= 0 && soldierRoomCol < ROOM_COLS &&
		soldierRoomRow >= 0 && soldierRoomRow < ROOM_ROWS) {
		switch (TileTypeAtColRow(soldierRoomCol, soldierRoomRow))
		{
			case ROOM_WALL: {
				soldier.x -= soldier.xspeed;
				soldier.y -= soldier.yspeed;
				soldier.xspeed = 0;
				soldier.yspeed = 0;
				break;
			}
			case ROOM_KEY://key
				{
					soldier.key_num++;
					console.log(soldier.key_num);//add for debug
					roomGrid[rowColToArrayIndex(soldierRoomCol, soldierRoomRow)] = ROOM_ROAD;
					break;
				}// end of room found
			case ROOM_DOOR://door
				{
					if (soldier.key_num == 0) {
						soldier.x -= soldier.xspeed;
						soldier.y -= soldier.yspeed;
						soldier.xspeed = 0;
						soldier.yspeed = 0;
						break;
					}
					else if (soldier.key_num > 0) {
						roomGrid[rowColToArrayIndex(soldierRoomCol, soldierRoomRow)] = ROOM_ROAD;
						soldier.key_num--;
						console.log(soldier.key_num)
						break;
					}
				}
			case ROOM_GOAL://up
				{
					lvl_num++;
					console.log(lvl_num);
					loadLevel(lvllist[lvl_num]);
					break;
				}
			case ROOM_TREE://down
				{
					lvl_num--;
					console.log(lvl_num);
					loadLevel(lvllist[lvl_num]);
					break;
				}
			case ROOM_MONSTER1:
				{
					var hp = 50;
					var atk = 15;
					var dfs = 10;
					var hit_num;
					hit_num = Math.floor(hp / (soldier.atk - dfs))
					if (soldier.atk > dfs) {
						if (soldier.dfs > atk) {
							roomGrid[rowColToArrayIndex(soldierRoomCol, soldierRoomRow)] = ROOM_ROAD;
							break;

						}
						else if (hit_num == 0) {
							roomGrid[rowColToArrayIndex(soldierRoomCol, soldierRoomRow)] = ROOM_ROAD;
							break;
						}
						else {
							soldier.hp = soldier.hp - hit_num * (atk - soldier.dfs);
							roomGrid[rowColToArrayIndex(soldierRoomCol, soldierRoomRow)] = ROOM_ROAD;
							break;
						}
					}
					else if (soldier.atk <= dfs || soldier.hp - hit_num * (atk - soldier.dfs) <= 0) {
					soldier.x -= soldier.xspeed;
						soldier.y -= soldier.yspeed;
						soldier.xspeed = 0;
						soldier.yspeed = 0;
						break;}
					
					
					
                }

		}
	} // end of valid col and row
} // end of soldierRoomHandling func
function rowColToArrayIndex(col, row) {
	return col + ROOM_COLS * row;
}

function drawRooms() {

	for (var eachRow = 0; eachRow < ROOM_ROWS; eachRow++) {
		for (var eachCol = 0; eachCol < ROOM_COLS; eachCol++) {

			var arrayIndex = rowColToArrayIndex(eachCol, eachRow);
			var tileKindHere = roomGrid[arrayIndex];
			var useImg = roomPics[tileKindHere];
			

			canvasContext.drawImage(useImg,
				ROOM_W * eachCol, ROOM_H * eachRow);

		} // end of for each col
	} // end of for each row

} // end of drawRooms func
function property_display(soldier) {
	colorText("my hp="+soldier.hp, 700, 25, "black");
}