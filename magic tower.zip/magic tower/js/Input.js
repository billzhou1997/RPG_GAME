const key_left=37;
const key_up=38;
const key_right=39;
const key_down=40;
const key_w = 87;
const key_a = 65;
const key_s = 83;
const key_d = 68;
var mouseX = 0;
var mouseY = 0;


function Input() {
	canvas.addEventListener('mousemove', updateMousePos);
	document.addEventListener('keydown', keyPressed)
	document.addEventListener('keyup', keyReleased)
	soldier1.setupinput(key_up, key_down, key_left, key_right);
	//soldier2.setupinput(key_w, key_s, key_a, key_d);
}
function updateMousePos(evt) {
	var rect = canvas.getBoundingClientRect();
	var root = document.documentElement;

	mouseX = evt.clientX - rect.left - root.scrollLeft;
	mouseY = evt.clientY - rect.top - root.scrollTop;

	// cheat / hack to test soldier in any position
	/*soldierX = mouseX;
	soldierY = mouseY;
	soldierSpeedX = 4;
	soldierSpeedY = -4;*/
}
function keyset(keyevent,soldier,setto) {
	if (keyevent.keyCode == soldier.controlkeyleft) { soldier.key_left = setto; }
	if (keyevent.keyCode == soldier.controlkeyright) { soldier.key_right = setto; }
	if (keyevent.keyCode == soldier.controlkeyup) { soldier.key_up = setto; }
	if (keyevent.keyCode == soldier.controlkeydown) { soldier.key_down = setto; }


}
	function keyPressed(evt)
	{ 
		keyset(evt,soldier1, true);
		//keyset(evt,soldier2, true);
}

function keyReleased(evt)
{// console.log(evt.keyCode);
	keyset(evt,soldier1, false);
	//keyset(evt,soldier2, false);
}

