


var canvas, canvasContext;
var soldier1 = new soldierClass();
//var soldier2 = new soldierClass();
window.onload = function () {
	canvas = document.getElementById('gameCanvas');
	canvasContext = canvas.getContext('2d');
	colorRect(0, 0, canvas.width, canvas.height, 'black');
	colorText("LOADING IMAGES", canvas.width / 2, canvas.height / 2, 'white');
	LoadImages();
}


function MainProgram()	{
	var framesPerSecond = 30;
	setInterval(updateAll, 1000/framesPerSecond);
	Input();
	loadLevel(lvl1)
}

function updateAll() {
	moveAll();
	drawAll();
}

function loadLevel(lvl) {
	roomGrid = lvl;
	soldier1.reset(soldier1Pic, "bill");
	//soldier2.reset(soldier2Pic, "liz");
}






function moveAll() {
	soldier1.move();
	//soldier2.move();
	
}

function clearScreen() {
	colorRect(0, 0, canvas.width, canvas.height, 'black'); 
}
function drawAll() {
	drawRooms();
	soldier1.draw();
	property_display(soldier1);
	//soldier2.draw()
}
